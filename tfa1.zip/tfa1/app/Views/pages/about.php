<?= view('partials/header', ['title' => $title]) ?>
<section class="intro">
    <h1>About this POS</h1>
    <p>This first version is a CodeIgniter 4 site with four pages. Customer and staff records are currently supplied by temporary static PHP arrays while the database layer is prepared.</p>
</section>
<?= view('partials/footer') ?>
