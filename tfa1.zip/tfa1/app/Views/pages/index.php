<?= view('partials/header', ['title' => $title]) ?>
<section class="intro">
    <h1>Point of Sale</h1>
    <p>A simple first look at the store workspace for customer and staff account management.</p>
    <div class="links">
        <a class="button" href="<?= site_url('customers') ?>">View customers</a>
        <a class="button" href="<?= site_url('users') ?>">View users</a>
    </div>
</section>
<?= view('partials/footer') ?>
