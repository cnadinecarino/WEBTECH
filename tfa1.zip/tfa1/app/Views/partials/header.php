<?php $baseUrl = rtrim(config('App')->baseURL, '/'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?> | POS</title>
    <style>
        :root { color-scheme: light; --ink: #17212b; --muted: #64727e; --line: #dce4e8; --accent: #0b7285; --paper: #f7faf9; }
        * { box-sizing: border-box; }
        body { margin: 0; background: var(--paper); color: var(--ink); font-family: Georgia, 'Times New Roman', serif; }
        header { background: #173f4a; color: white; }
        .nav, main { width: min(1080px, calc(100% - 40px)); margin: 0 auto; }
        .nav { display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 20px 0; }
        .brand { color: white; font-size: 1.35rem; font-weight: bold; text-decoration: none; }
        nav { display: flex; flex-wrap: wrap; gap: 18px; }
        nav a { color: #d7eef0; text-decoration: none; }
        nav a:hover, nav a:focus { color: white; text-decoration: underline; }
        main { padding: 64px 0; }
        h1 { margin: 0 0 14px; font-size: clamp(2.2rem, 5vw, 4.5rem); line-height: 1; }
        p { color: var(--muted); font-family: Arial, sans-serif; line-height: 1.6; }
        .intro { max-width: 650px; }
        .links { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 30px; }
        .button { background: var(--accent); color: white; padding: 12px 18px; text-decoration: none; font-family: Arial, sans-serif; }
        .button:hover, .button:focus { background: #075766; }
        table { width: 100%; border-collapse: collapse; background: white; font-family: Arial, sans-serif; }
        th, td { border-bottom: 1px solid var(--line); padding: 15px 16px; text-align: left; }
        th { background: #e7f1f0; color: #24525b; font-size: .82rem; letter-spacing: .05em; text-transform: uppercase; }
        tr:last-child td { border-bottom: 0; }
        @media (max-width: 640px) { .nav { align-items: flex-start; flex-direction: column; } main { padding: 42px 0; } table { display: block; overflow-x: auto; white-space: nowrap; } }
    </style>
</head>
<body>
<header>
    <div class="nav">
        <a class="brand" href="<?= $baseUrl ?>/">POS Desk</a>
        <nav aria-label="Primary navigation">
            <a href="<?= $baseUrl ?>/">Home</a>
            <a href="<?= $baseUrl ?>/about">About</a>
            <a href="<?= $baseUrl ?>/customers">Customers</a>
            <a href="<?= $baseUrl ?>/users">Users</a>
        </nav>
    </div>
</header>
<main>
