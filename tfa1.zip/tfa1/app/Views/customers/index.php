<?= view('partials/header', ['title' => $title]) ?>
<h1>Customer Accounts</h1>
<p>Customer records currently loaded from a temporary static array.</p>
<table>
    <thead><tr><th>Full name</th><th>Email</th><th>Phone</th></tr></thead>
    <tbody>
    <?php foreach ($customers as $customer): ?>
        <tr>
            <td><?= esc($customer['full_name']) ?></td>
            <td><?= esc($customer['email']) ?></td>
            <td><?= esc($customer['phone']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?= view('partials/footer') ?>
