<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        $users = [
            ['username' => 'jsmith', 'full_name' => 'Jamie Smith', 'role' => 'Manager'],
            ['username' => 'apatel', 'full_name' => 'Asha Patel', 'role' => 'Cashier'],
            ['username' => 'lgarcia', 'full_name' => 'Luis Garcia', 'role' => 'Cashier'],
            ['username' => 'mjohnson', 'full_name' => 'Morgan Johnson', 'role' => 'Inventory Clerk'],
            ['username' => 'rlee', 'full_name' => 'Riley Lee', 'role' => 'Administrator'],
        ];

        return view('users/index', [
            'title' => 'User Accounts',
            'users' => $users,
        ]);
    }
}
